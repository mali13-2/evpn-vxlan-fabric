# Automated EVPN-VXLAN Data Center Fabric

IT 475 / IT 377 individual project, Illinois State University.

A leaf-spine data center network built with containerlab and FRRouting, deployed from code, and tested automatically.

## Status
- [x] Lab environment (GitHub Codespaces + containerlab)
- [x] Lab 00: two-router eBGP test
- [x] eBGP underlay (2 spines, 4 leaves) with ECMP
- [x] EVPN-VXLAN overlay with isolated tenants (ai, web)
- [x] Python intent-based config generator
- [x] Automated tests (pytest)
- [ ] Failover experiments (link vs. silent failure, BFD off vs. on)
- [ ] Spanning tree baseline for comparison
- [ ] CI pipeline (GitHub Actions)

## Run the fabric
Open this repository in GitHub Codespaces, then:

```bash
pip install -r requirements.txt
python fabric/generate.py
sudo containerlab deploy -t fabric/build/dc1.clab.yml
```

`fabric/intent.yml` is the single source of truth. `generate.py` turns it into
every router configuration and the containerlab topology, so the whole network
can be rebuilt from one file.

## Failover experiment
```bash
python experiments/failover.py --runs 5
python experiments/plot_failover.py
```
Results are saved in `results/failover.csv` and `results/failover.png`.

## Test it
```bash
pytest -v
```
The tests read `intent.yml` and check that the live network matches it: BGP
sessions, ECMP across all spines, EVPN VNIs, same-tenant reachability, and
cross-tenant isolation.
